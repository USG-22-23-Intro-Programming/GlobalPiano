#Greeting


def greeting():

#sets name = whatever the user's input is
    name = input("Create your login username:")
    print("Oh goodness! If it isn't the great " + name + "!")
    print("What a honor to meet you, good sir!")

#IsMultiple!


def isMultiple():

#jusr a line break to make it prettier
    print("")

    print("Let's see if two numbers are multiples of eachother!")

#stores num1 and num2 as whatever user says 
    num1 = int(input("Tell me the first number: "))
    num2 = int(input("Tell me the second number: "))

#outcome = remainder of num1 / num2 or num1 mod num2
    outcome = num1 % num2
#if outcome = 0 it means they are multiples (4/2, remainder = 0, but 5/2, remainder = 1)
    if outcome==0:
        print(str(num1) + " is a multiple of " + str(num2))
    else:
        print("Nope! " + str(num1) + " is not a multiple of " + str(num2))


#Palindrome
        
def palindrome():
    s = input("Type in a palindrome you want to test: ")

#length of the string/int
    length = len(s)

#for loop to repeat
#i starts at 0 and adds one each time
#!= is does not equal

    for i in range(length):
#length is total chars, but the actual "s" starts at 0, so -1 from initial to get final character
        if s[i] != s[length - 1 - i]:
            return False
    return True


 

def PS1main():
    greeting()
    isMultiple()
    answer = palindrome()
    print(answer)



if __name__ == "__main__":
    PS1main()



'''



def palindrome():
    print("")

    x = input("enter a word:")
    leng = len(x)

    for i in range(leng):
        if x[0] == x[leng-1-i]:
            print("it's a palindrome!")
        else:
            print("it isn't a palindrome :c")

def main():
    #greeting()
    
    #answer = palindrome1()
    #print(answer)

    isMultiple(10, 5)
    
if __name__ == "__main__":
    main()
        

#w3schools:

num=int(input("Enter a number:"))
temp=num
rev=0
while(num>0):
    dig=num%10
    rev=rev*10+dig
    num=num//10
if(temp==rev):
    print("The number is palindrome!")
else:
    print("Not a palindrome!")'''









