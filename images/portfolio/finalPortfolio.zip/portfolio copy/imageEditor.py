from graphics import*
from Button import*



def Imain():

#i forgot what kkk was, but i don't wanna delete it bc what if it's useful?
#does no harm by leaving it
    kkk = 30

    win = GraphWin("Image Editor", 700, 600)
    win.setBackground("white")

#image
    img = Image(Point(350, 300), "uwu.png")
    img.draw(win)

#buttons
    Q = Button(win, Point(580, 450), Point(680, 525), "plum1", "QUIT")
    L = Button(win, Point(580, 50), Point(680, 125), "LightSteelBlue1", "Lighten")
    D = Button(win, Point(580, 150), Point(680, 225), "LightSteelBlue1", "Darken")
    C = Button(win, Point(580, 250), Point(680, 325), "MistyRose1", "Contrast")
    G = Button(win, Point(580, 350), Point(680, 425), "grey65", "Grayscale")
    I = Button(win, Point(30, 50), Point(130, 125), "orange", "Inverse")
    O = Button(win, Point(30, 150), Point(130, 225), "tomato", "only Red")
    #R = Button(win, Point(30, 250), Point(130, 325), "plum1", "Reset")

#inf loop
    while True:
        
        m = win.getMouse()

#things inside the buttons are methods programmed below
        if D.isClicked(m):
            darken(img)
        if L.isClicked(m):
            lighten(img)
        if I.isClicked(m):
            inverse(img)
        if C.isClicked(m):
            contrast(img)
        if G.isClicked(m):
            grayscale(img)
        if O.isClicked(m):
            onlyRed(img)
        #if R.isClicked(m):
            #reset(img, win)
#breaks inf loop
        if Q.isClicked(m):
            break
#closes window
    win.close()

#takes in image as parameter to know which image to get pixels from
def grayscale(img):
#gets the amount of pixels x and y
    x=img.getWidth()
    y = img.getHeight()

#repeats for every x value (i)
    for i in range(x):
#repeats for every y value (j) within each x value
        for j in range(y):
#gets x,y coords of pixel
            P=img.getPixel(i,j)
#rgb values of P
            red = P[0]
            gre = P[1]
            blu = P[2]
#fins the average of all three rgb values added together
            gray = float(red + gre + blu)
            gray = gray / 3
            gray = round(gray)
#sets rgb value to that average
            red = gray
            blu = gray
            gre = gray
#replaces rgb value with those numbers
            c = color_rgb(red, gre, blu)
#replaces pixel with i,j (x,y) and color
            img.setPixel(i, j, c)


#attempts at blur that failed
'''

def blur(img):
    x=img.getWidth()
    y = img.getHeight()

    for i in range(x):
        for j in range(y):
            
            if i == 0:
                P=img.getPixel(i,j)
                P1=img.getPixel(i + 1,j)
                if j == 0:
                    P3=img.getPixel(i,j + 1)
                    
                if j == y - 1:
                    P4=img.getPixel(i,j - 1)
                    
                else:
                    P3=img.getPixel(i,j + 1)
                    P4=img.getPixel(i,j - 1)
                    
                    
            if i == x - 1:
                P=img.getPixel(i,j)
                P2=img.getPixel(i - 1,j)
                if j == 0:
                    P3=img.getPixel(i,j + 1)
                if j == y - 1:
                    P4=img.getPixel(i,j - 1)
                else:
                    P3=img.getPixel(i,j + 1)
                    P4=img.getPixel(i,j - 1)

            else:
                P=img.getPixel(i,j)
                P1=img.getPixel(i + 1,j)
                P2=img.getPixel(i - 1,j)
                if j == 0:
                    P3=img.getPixel(i,j + 1)
                if j == y - 1:
                    P4=img.getPixel(i,j - 1)
                else:
                    P3=img.getPixel(i,j + 1)
                    P4=img.getPixel(i,j - 1)
                

            red = P[0]
            gre = P[1]
            blu = P[2]

            red1 = P1[0] #right
            gre1= P1[1]
            blu1 = P1[2]

            red2 = P2[0]#Left
            gre2 = P2[1]
            blu2 = P2[2]

            red3 = P3[0] #P3: bottom
            gre3 = P3[1]
            blu3 = P3[2]

            red4 = P4[0] #P4: top
            gre4 = P4[1]
            blu4 = P4[2]

            if i == 0:
                if j == 0:
                    rr = red + red1 + red3
                    red = rr / 3

                    bb = blu + blu1 + blu3
                    blu = bb / 3

                    gg = gre + gre1 + gre3
                    gre = gg / 3
                    
                if j == y:
                    rr = red + red1 + red4
                    red = rr / 3

                    bb = blu + blu1 + blu4
                    blu = bb / 3

                    gg = gre + gre1 + gre4
                    gre = gg / 3
                    
                else:
                    rr = red + red1 + red3 + red4
                    red = rr / 4

                    bb = blu + blu1 + blu3 + blu4
                    blu = bb / 4

                    gg = gre + gre1 + gre3 + gre4
                    gre = gg / 4
                    
                    
            if i == x:
                if j == 0:
                    rr = red + red2 + red3
                    red = rr / 3

                    bb = blu + blu2 + blu3
                    blu = bb /3

                    gg = gre + gre2 + gre3
                    gre = gg / 3
                if j == y:
                    rr = red + red2 + red4
                    red = rr / 3

                    bb = blu + blu2 + blu4
                    blu = bb / 3

                    gg = gre + gre2 + gre4
                    gre = gg / 3
                else:
                    rr = red + red2 + red3 + red4
                    red = rr / 4

                    bb = blu + blu2 + blu3 +blu4
                    blu = bb / 4

                    gg = gre + gre2 + gre3 + gre4
                    gre = gg / 4

            else:
                
                if j == 0:
                    rr = red + red1 + red2 + red3
                    red = rr / 4

                    bb = blu + blu1 + blu2 + blu3
                    blu = bb / 4

                    gg = gre + gre1 + gre2 + gre3
                    gre = gg / 4
                if j == y:
                    rr = red + red1 + red2 + red4
                    red = rr / 4

                    bb = blu + blu1 + blu2 + blu4
                    blu = bb / 4

                    gg = gre + gre1 + gre2 + gre4
                    gre = gg / 4
                else:
                    rr = red + red1 + red2 + red4 + red3
                    red = rr / 5

                    bb = blu + blu1 + blu2 + blu4 + red3
                    blu = bb / 5

                    gg = gre + gre1 + gre2 + gre4 + red3
                    gre = gg / 5
                    
            c = color_rgb(red, gre, blu)
            img.setPixel(i, j, c)
                
            
'''

#takes in image as parameter to know which image to get pixels from
def onlyRed(img):
#similar to above method
    x=img.getWidth()
    y = img.getHeight()

    for i in range(x):
        for j in range(y):
            P=img.getPixel(i,j)

            red = P[0]
            gre = P[1]
            blu = P[2]

#if the r value is far greater than g and b, things stay as it is
            if (red > gre + 20) and (red > blu + 20):
                red = red
                gre = gre
                blu = blu

#if not, make the pixel gray, similar to grayscale
            else:

                gray = float(red + gre + blu)
                gray = gray / 3
                gray = round(gray)

                red = gray
                blu = gray
                gre = gray

#same way setting it up
            c = color_rgb(red, gre, blu)
            img.setPixel(i, j, c)
                

            
            

def inverse(img):
#similar to abome method
    x=img.getWidth()
    y = img.getHeight()

    for i in range(x):
        for j in range(y):
            P=img.getPixel(i,j)

            red = P[0]
            gre = P[1]
            blu = P[2]

#this is the inverse values of rgb
            red = (255 - red)
            gre = (255 - gre)
            blu = (255 - blu)

#sets color as those inverse values
            c = color_rgb(red, gre, blu)
            img.setPixel(i, j, c)
            
 
def contrast(img):
#similar to above method
    x=img.getWidth()
    y = img.getHeight()

    for i in range(x):
        for j in range(y):
            P=img.getPixel(i,j)

            red = P[0]
            gre = P[1]
            blu = P[2]
#337.5 is 255+255+255 (max values) / 2
#if they are considered "dark" (less than 337.5) ((255,255,255) is white, (0,0,0) = black)
            if (red + blu + gre < 337.5) or red + blu + gre == 337.5:
#if red value != 15, meaning that it isn't at it's darkest, make it 15 values darker
                if red - 15 > 0:
                    red = red - 15
#if red - 15 is negative, just make it 0
                else:
                    red = 0
#same with blue as red
                if blu - 15 > 0:
                    blu = blu - 15
                else:
                    blu = 0

#same with green as red
                if gre - 15 > 0:
                    gre = gre - 15
                else:
                    gre = 0

#this is if they are considered "light" (more than 337.5) ((255,255,255) is white, (0,0,0) = black)
#same thing above, but values are higher instead of lower
            else:
                if red + 15 < 255:
                    red = red + 15
                else:
                    red = 255

                if blu + 25 < 255:
                    blu = blu + 25
                else:
                    blu = 255
                
                if gre + 25 < 255:
                    gre = gre + 25
                else:
                    gre = 255
        

            c = color_rgb(red, gre, blu)
            img.setPixel(i, j, c)

#basically constrast but only with the lighten part / bottom half
def lighten(img):
    x=img.getWidth()
    y = img.getHeight()

    for i in range(x):
        for j in range(y):
            P=img.getPixel(i,j)

            red = P[0]
            gre = P[1]
            blu = P[2]

            if red + 50 < 255:
                red = red + 50
            else:
                red = 255

            if blu + 50 < 255:
                blu = blu + 50
            else:
                blu = 255
                
            if gre + 50 < 255:
                gre = gre + 50
            else:
                gre = 255
        

            c = color_rgb(red, gre, blu)
            img.setPixel(i, j, c)

#basically constrast but only with the darken part / top half
def darken(img):
    x=img.getWidth()
    y = img.getHeight()

    for i in range(x):
        for j in range(y):
            P=img.getPixel(i,j)

            red = P[0]
            gre = P[1]
            blu = P[2]

            if red - 50 > 0:
                red = red - 50
            else:
                red = 0

            if blu - 50 > 0:
                blu = blu - 50
            else:
                blu = 0
                
            if gre - 50 > 0:
                gre = gre - 50
            else:
                gre = 0
        

            c = color_rgb(red, gre, blu)
            img.setPixel(i, j, c)

#def reset(img, win):
    #Imain(win)

if __name__ == "__main__":

#window
    window = GraphWin("Image Editor", 700, 600)
    window.setBackground("white")
    
    Imain()






