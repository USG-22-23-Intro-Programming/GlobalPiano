

#def factorial(num):


def factorial(x):
#sets up y as 1
    y = 1
#makes that number a integer instead of a string
    x=int(x)
#starts at i=2 and ends at i=x (i nevr reaches x+1, but it has to reach x bc we don't need to multiply by 1 nor 0
    for i in range(2, x+1):
        y = y * i
    
        
    print("The factorial of " + str(x) + " is: " + str(y))
 

#Double it!

def doubleIt():
    l = input("double a phrase here: ")
#empty string to add stuff to, just like a list
    s=""

#i = each character in input "l"
    for i in l:
#whatever's previously in the string (already doubled) + next character doubled
        s = s + i + i
        
    print(s)



#CamelCode


def camelCode():

#user input file name
    cry = input(str("Enter file name:"))
#title capitalizes first letter of word to upper case
    y = cry.title()
#deletes spaces
    a = y.replace(" ", "")
#replaces / with -
    b = a.replace("/", "-")
#lowercases the first character + rest of file name
    c = b[0].lower() + b[1:]

    print(c)




def PS2main():
    
    factorial(5)

    camelCode()

    doubleIt()


if __name__ == "__main__":
    PS2main()




