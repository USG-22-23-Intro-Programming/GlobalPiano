
#1
def currencyConverter():

#list of currencies to print for the user to see
    currencies = ["1. USD", "2. Euro", "3. Chinese Yuan", "4. Turkish Lira"]
#dicts to translate user input number to the corresponding currency
    forusercurr = {"1" : "USD", "2" : "Euro", "3" : "Chinese Yuan", "4" : "Turkish Lira"}
    forwantcurr = {"1" : "USD", "2" : "Euro", "3" : "Chinese Yuan", "4" : "Turkish Lira"}

#prints each currency in the list
    for currency in currencies:
        print(currency)
#sets usercurr to the currency they have (number then translated into currency)
    usercurr = input("Choose your currency from the list above (in number): ")
#sets up money
    money = float(input("How much money do you have in that currency: "))

#prints each currency in the list
    for currency in currencies:
        print(currency)
#sets usercurr to the currency they want (number then translated into currency)
    wantcurr = input("Choose the currency you want to convert into from the list above (in number): ") 


#end is the translation of what the user has to USD rate
    end = {"USD" : 1, "Euro" : .984, "Chinese Yuan" : 0.14, "Turkish Lira" : 0.054}
#end2 is the translation of what the user wants from USD to the correct rate
    end2 = {"USD" : 1, "Euro" : 1.02, "Chinese Yuan" : 7.29, "Turkish Lira" : 18.62}

#gets value (USD, Euro, etc) from what user has from previous dictionary (user inputs number (key))
    y = forusercurr.get(usercurr)
#sets rate1 = rate of what user has translated to USD from dict END
    rate = float(end.get(y))
#the amount of money they HAVE in USD
    USD = money * rate

#gets value (USD, Euro, etc) from what user wants from previous dictionary (user inputs number (key))
    getRate = forwantcurr.get(wantcurr)
#gets rate of USD to the currency of whatever user wants from dict END2
    rate2 = float(end2.get(getRate))
#final amount of money in what the user wants
    final = USD * rate2
#rounds to 2 decimal digits
    final = round(final, 2)
    print(final)



#2

def groceryList(sample):

#dictionary of food name : price
    foods = {"apple" : 1.50,
             "orange" : 1.00,
             "banana" : 1.00,
             "bagel" : 1.25,
             "cabbage" : 1.50,
             "spinach" : 4.25,
             "milk" : 2.75,
             "eggs" : 3.25,
             "cake" : 8.00,
             "pasta" : 3.50}
    
    print("During your journey in the best grocery store, you purchased:")
#for each item in parameter list
    for item in sample:
#tells what you bought
        print(item)
#price starts at 0
    money = 0
#for each item in list you bought
    for item in sample:
#gets price of the food
        x = foods.get(item)
#price = previous price + price of new added food
        money = money + x
#total price
    print("Your total is: $" +str(money))


def PS3main():
    currencyConverter()
    L = ["apple", "banana", "spinach", "banana"]
    groceryList(L)

if __name__ == "__main__":
    PS3main()
